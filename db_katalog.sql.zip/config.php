<?php
$db = mysqli_connect("localhost","root","","db_katalog");
?>
