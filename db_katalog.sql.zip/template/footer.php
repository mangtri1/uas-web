    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          <a href="index.php" style="color:white;">E-KATALOG</a> &copy; 2023
        </p>
        <a href="#" class="go-top">
          <i class="fa fa-angle-up"></i>
        </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../asset/lib/jquery/jquery.min.js"></script>
  <script src="../asset/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="../asset/lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="../asset/lib/jquery/jquery-3.4.0.min.js"></script>
  <!--common script for all pages-->
  <script src="../asset/lib/common-scripts.js"></script>
  <!--script for this page-->

  <!--Date Bootsrap js-->
  <script src="../asset/lib/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <!--Boostrap Js-->
  <script src="../asset/lib/bootstrap-4.3.1/js/bootstrap.min.js"></script>
</body>
</html>